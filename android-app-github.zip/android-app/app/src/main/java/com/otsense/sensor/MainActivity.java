package com.otsense.sensor;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.UUID;

/** One-tap OT Sense sensor: starts the Python sensor (otsense.py phone) inside the app and shows its window in a WebView. */
public class MainActivity extends Activity {
    private static String KEY = null;          // one sensor per app process, even if the screen is rotated
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);   // phones stop apps when the screen sleeps
        web = new WebView(this);
        setContentView(web);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        if (KEY == null) {
            KEY = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
            final String dir = getFilesDir().getAbsolutePath();
            final String key = KEY;
            new Thread(() -> Python.getInstance().getModule("androidmain").callAttr("start", dir, key)).start();
        }
        final String url = "http://127.0.0.1:8099/#" + KEY;
        new Thread(() -> {
            for (int i = 0; i < 60; i++) {                      // wait up to 15 s for the sensor page to come up
                try (Socket s = new Socket()) {
                    s.connect(new InetSocketAddress("127.0.0.1", 8099), 300);
                    runOnUiThread(() -> web.loadUrl(url));
                    return;
                } catch (Exception e) {
                    try { Thread.sleep(250); } catch (InterruptedException ie) { return; }
                }
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);      // keep the sensor running; do not close it
    }
}
