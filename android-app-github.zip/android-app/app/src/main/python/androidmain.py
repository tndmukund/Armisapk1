import os
import threading

import otsense


def start(datadir, key):
    """Called by MainActivity: run the sensor window server inside the app (returns at once)."""
    conf = os.path.join(datadir, "sensor.conf")
    threading.Thread(target=otsense.run_phone, args=(["--conf", conf, "--port", "8099", "--key", key],), daemon=True).start()
